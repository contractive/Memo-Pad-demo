package com.demo.huynt.mdcinterview;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.GetDataCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Categories extends AppCompatActivity {

    GridView gridCategories;
    ArrayList<Category> cate_data;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categories);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        Bundle b = getIntent().getExtras();
        String[] resultArr = b.getStringArray("SelectedInterviewers");
        String candicate = b.getString("Candicate");
        Toast.makeText(this, resultArr[0] + "\n" + candicate, Toast.LENGTH_SHORT).show();

        String[] cate_name;
        Resources resource = this.getResources();
        cate_name = resource.getStringArray(R.array.categories);

        int[] cate_pic = {R.drawable.android, R.drawable.ios};

        cate_data = new ArrayList<>();
        getCategoriesData();




        /*for(int i = 0;i<cate_name.length;i++){

            cate_data.add(new Category(cate_name[i]));
        }*/



    }

    public void getCategoriesData() {
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Template");
        query.findInBackground(new FindCallback<ParseObject>() {


            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                final ArrayList<Category> cate_temp = new ArrayList<Category>();
                if (e == null) {
                    // If there are results, update the list of posts
                    // and notify the adapter
                    cate_data.clear();


                    for (int i = 0; i < objects.size(); i++) {
                        cate_data.add(new Category(objects.get(i).getString("objectId"),objects.get(i).getString("title")));
                        cate_temp.add(new Category(objects.get(i).getString("objectId"),objects.get(i).getString("title")));
                    }
                    gridCategories = (GridView) findViewById(R.id.gridView);
                    gridCategories.setAdapter(new CategoriesAdapter(Categories.this, cate_data));
                } else {
                    Log.d(getClass().getSimpleName(), "Load Data Error: " + e.getMessage());
                }

                gridCategories.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        String Cat_id = cate_temp.get(position).getCat_ID();
                        Toast.makeText(Categories.this,Cat_id ,Toast.LENGTH_SHORT).show();
                        CategoryItemClick(Cat_id);
                    }
                });

            }
        });

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main,menu);

        return true;
    }


    private void CategoryItemClick(String cat) {

        Intent intent = new Intent(Categories.this,ResultActivity.class);
        intent.putExtra("CateID","jAexLPEf6E");
        startActivity(intent);

    }

}



class CategoriesAdapter extends BaseAdapter{

    Context context;
    ArrayList<Category> cate_data;
    public CategoriesAdapter(Context context,ArrayList<Category> cate_data){

        this.context = context;
        this.cate_data = cate_data;
    }
    @Override
    public int getCount() {
        return cate_data.size();
    }

    @Override
    public Object getItem(int position) {
        return cate_data.get(position);
    }

    @Override
    public long getItemId(int position) {

        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View grid;
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null) {

            grid = new View(context);
            grid = inflater.inflate(R.layout.single_category, null);
            TextView textView = (TextView) grid.findViewById(R.id.txtItem_category_name);
            ImageView imageView = (ImageView)grid.findViewById(R.id.imgItem_category_pic);
            textView.setText(cate_data.get(position).cate_name);
            imageView.setImageResource(R.drawable.android);
        } else {
            grid =  convertView;
        }


        return grid;
    }

}
/*class ViewHolder
{
    public ImageView imgCate_pic;
    public TextView txtCate_name;
    ViewHolder(View v){
        imgCate_pic = (ImageView) v.findViewById(R.id.imageView);
        txtCate_name = (TextView) v.findViewById(R.id.txtCate_name);
    }
}*/
class Category {

    public Bitmap cate_bitmap;
    public int cate_imageID = R.drawable.android;
    String cate_name;
    public String cat_ID;

    public String getCat_ID() {
        return cat_ID;
    }

    public void setCat_ID(String cat_ID) {
        this.cat_ID = cat_ID;
    }


    public Bitmap getImageID() {
        return cate_bitmap;
    }

    public void setImageID(Bitmap imageID) {
        this.cate_bitmap = imageID;
    }

    public String getCate_name() {
        return cate_name;
    }

    public void setCate_name(String cate_name) {
        this.cate_name = cate_name;
    }

    public Category(String cat_ID, String cate_name) {

        this.cat_ID = cat_ID;
        this.cate_name = cate_name;

    }
}
