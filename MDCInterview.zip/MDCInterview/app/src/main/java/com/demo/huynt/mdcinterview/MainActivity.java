package com.demo.huynt.mdcinterview;

import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    ListView lvInterviewers;
    ArrayList<String> list_selected_interviewers = new ArrayList<>();

    ArrayAdapter<String> interview_adapter;
    EditText txtCandicate;
    int count_interviewers = 0;

    public ArrayList<Interviewer> interviewers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        lvInterviewers = (ListView) findViewById(R.id.lvInterviewers);
        txtCandicate = (EditText) findViewById(R.id.txtCandicate);

        interviewers = new ArrayList<>();
        /*final ArrayList<String> listInterviewers = new ArrayList<String>();
        String[] values = getResources().getStringArray(R.array.interviewer);
        for(int i=0; i<values.length;i++){
            listInterviewers.add(values[i]);
        }

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_multiple_choice, listInterviewers);
        lvInterviewers.setAdapter(adapter);

        interviewers = new ArrayList<>();*/


        refreshInterviewersList();

        lvInterviewers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                list_selected_interviewers.clear();
                SparseBooleanArray checked = lvInterviewers.getCheckedItemPositions();
                for (int i = 0; i < checked.size(); i++) {
                    // Item position in adapter
                    if (checked.valueAt(i))
                        list_selected_interviewers.add(interviewers.get(i).getInter_name());
                }

                Toast.makeText(MainActivity.this,list_selected_interviewers.toString(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void refreshInterviewersList() {
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Interviewer");
        query.findInBackground(new FindCallback<ParseObject>() {

            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null) {
                    // If there are results, update the list of posts
                    // and notify the adapter
                    interviewers.clear();


                    for (int i=0; i<objects.size();i++) {

                        interviewers.add(new Interviewer(objects.get(i).getString("name"),objects.get(i).getString("email")));
                    }
                    ArrayList<String> temp_interviewer = new ArrayList<>();
                    for (int i=0; i<interviewers.size();i++){
                        temp_interviewer.add(interviewers.get(i).getInter_name());
                    }
                    interview_adapter = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_list_item_multiple_choice, temp_interviewer);
                    lvInterviewers.setAdapter(interview_adapter);
                    lvInterviewers.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                } else {
                    Log.d(getClass().getSimpleName(), "Load Data Error: " + e.getMessage());
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int res_id = item.getItemId();
        if(res_id == R.id.action_next){
            Intent intent = new Intent(getApplicationContext(),
                    Categories.class);

            // Create a bundle object
            String[] outputStrArr = new String[list_selected_interviewers.size()];

            for (int i = 0; i < list_selected_interviewers.size(); i++) {
                outputStrArr[i] = list_selected_interviewers.get(i);
            }
            Bundle b = new Bundle();
            b.putStringArray("SelectedInterviewers", outputStrArr);
            b.putString("Candicate",txtCandicate.getText().toString());
            intent.putExtras(b);
            startActivity(intent);

        }


        return true;
    }
}
