package com.demo.huynt.mdcinterview;

import android.app.Application;

import com.parse.Parse;
import com.parse.ParseObject;

/**
 * Created by HuyNT11 on 9/14/2016.
 */
public class ParseApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Parse.initialize(this, "kj9O1QxNR37dSqad2cZvjChb3N1D3qSJ1fSGw9Vd", "MQubCn04ED4SyOZWBXPC34QhJeHY6sLTf9LNJC7E");

        
    }
}
