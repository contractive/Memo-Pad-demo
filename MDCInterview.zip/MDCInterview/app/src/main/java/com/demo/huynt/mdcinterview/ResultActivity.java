package com.demo.huynt.mdcinterview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    ListView lvtopic_main;

    ArrayList<String> topic_arr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        lvtopic_main = (ListView) findViewById(R.id.lvtopic_main);
        topic_arr = new ArrayList<>();

        refreshTopicsList();

    }

    private void refreshTopicsList() {
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Comments");
        query.whereEqualTo("post", thePostObject );
        query.findInBackground(new FindCallback<ParseObject>() {
            public void done(List<ParseObject> comments, ParseException e) {
                if (e == null) {
                    // "comments" is now a list of the comments
                } else {
                    // Something went wrong...
                }
            }
        });
    }
}
